The scripts and configuration files in this folder are templates that get
customized for each image.  The values wrapped in percent symbols, e.g.,
%%FOO%%, get populated by actual values by the script create_image.pl.
